package org.learning.hellospringmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
