package org.learning.hellospringmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Random;

@Controller
@RequestMapping("/")
public class IndexController {
    @GetMapping
    // numeri random da 1 a 6
    /*public String index(Model model){
        Random random = new Random();
        int numberRandom = random.nextInt(1, 6);
        model.addAttribute("numberRandom", numberRandom);
        return "randomNumber";

    }*/
    //numeri random da 1 a scelta utente
    public String index(@RequestParam int maxNumber, Model model){
        Random random = new Random();
        int numberRandom = random.nextInt(1, maxNumber);
        model.addAttribute("numberRandom", numberRandom);
        return "randomNumber";

    }
}
